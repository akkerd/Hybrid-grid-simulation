function [ output_args ] = calcGenerators( input_args )
%CALCGENERATORS Summary of this function goes here
%   Detailed explanation goes here
    %% WindTurbines
        freqWT = 0;
        totalPowWT = 0;
        powWT = 0;
        sumFreqWT = 0;
        totalFreqWT = 0;

        % Loop for getting total frequency and power for all the WTNodes
        for cHydro = 1:numWT
            freqWT = MiCentral.Generators.WTNodes.( fnWT{numWT} ).getFreqFromEuro( gPrice ); % Freq of the WTNode number 'c'
            sumFreqWT = sumFreqWT + freqWT; % Sum of all frequencies
            powWT = MiCentral.Generators.WTNodes.( fnWT{numWT} ).getPowerFromFreq( freqWT ); 
            totalPowWT = totalPowWT + powWT   % Sum the power of the WTNode 'c' and sum it to the total
        end    
        
        % Results of the WT Grid sent to the Central eNode
        totalFreqWT = sumFreqWT / numWT % Result freq of WT Grid sent to Central eNode
        totalPowWT          % Result total power of WT Grid sent to Central eNode

    % gPrice = 0.0648; % It's the starting price of the PV for now. Needs to change
    %% PhotoVoltaics
        freqPV = 0;
        totalPowPV = 0;
        powPV=0;
        sumFreqPV = 0;
        totalFreqPV = 0;

        % Loop for getting total frequency and power for all the PVNodes
        for cHydro = 1:numPV
            freqPV = MiCentral.Generators.PVNodes.( fnPV{numPV} ).getFreqFromEuro( gPrice ); % Freq of the PVNode number 'c'
            sumFreqPV = sumFreqPV + freqPV; % Sum of all frequencies
            % totalFreqPV = sumFreqPV / c;
            %freqPV = 47.512
           powPV = powPV + MiCentral.Generators.PVNodes.( fnPV{numPV} ).getPowerFromFreq( freqPV ) ; % Sum the power of the PVNode 'c' and sum it to the total
        end
        
        % Results of the PV Grid sent to the Central eNode
        totalFreqPV = sumFreqPV / numPV
        totalPowPV = powPV
        generatorsTotalFreq = str2num( sprintf('%.2f', (sumFreqPV + sumFreqWT) / (numPV + numWT) ))    % TOTAL FREQ WITHOUT Stab. Controllers
        generatorsTotalPow = totalPowWT + totalPowPV                                                   % TOTAL POWER WITHOUT Stab. Controllers
        
    %% Mange the Price for all the generators
        generatorsTotalEuro = generatorsTotalPow * tSample * (gPrice/(1000*tSample))
        
    %% Caculate the power needed for stability
        powForStability = MiCentral.getPowerForStability( generatorsTotalFreq, gPowerGap)
        
    %% Fix the stabilization problem
        gridFreq = generatorsTotalFreq; % The grid frequency is generators frequency because otherwise you have no stablility control
        
    % if( false) % This is for TRIALS only. Skip the stabilizers
        %stableCounter = 1;
    stableSolution = false;

end

