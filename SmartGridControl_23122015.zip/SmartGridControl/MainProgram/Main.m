
clc
clear all
close all

tic 
%% Add paths
    addpath('../Models');
    addpath('../Utils');
    addpath('../Work');
    addpath('../MainProgram');
    addpath('../Forecasts');
    addpath('../Grids');
    
initPrice = 0.0003;
initPrice = priceTransform( initPrice ) % euros per watts for each 15 minutes

% LOCAL VARIABLES
possibleSolution = false;
gapProposal = 0;
tSample = 0.25;
stableFreq = 50.00;
percentOverPower = 0.1;
gridType = 2;

% Select the correct path of the XMLs depending on the gridType 
switch(gridType)
     case 0
        elementPath = ('../Work/Grids/Grid_0_1WT_1D');
    case 1
        elementPath = ('../Work/Grids/Grid_1_2WT_1D');
    case 2
        elementPath = ('../Work/Grids/Grid_2_1WT_1D_1H');
    case 3
        elementPath = ('../Work/Grids/Grid_3_1WT_1PV_1D_1H');
    case 4 
        elementPath = ('../Work/Grids/Grid_4_ 3WT_1PV_1D_2H'); 
   
end

addpath( elementPath );
    

%% Create MiCentral
    % XML
    XML='CentraleNode.xml';
    
    % scheduleXML
     scheduleXML = [];
     
    % currentTime
     currentTime=0; %We do not need this variable
     
    % OptimProblem
     OptimProblem.Price = initPrice; % It's in euros per Kwh
     OptimProblem.possibleSolution = possibleSolution;
     
    % OptimParams
     OptimParams.horizon = 24; % I suppose that this time goes in hours.
     
     OptimParams.tSample = tSample; % I suppose that this time goes in hours.
     OptimParams.updatePeriod=[];
     OptimParams.stableFreq = stableFreq;
     
    % predictions 
    predictions=[];
    
    % measures
     measures=[]; %Not used      
     

     MiCentral = CentraleNode(XML, scheduleXML, currentTime, OptimParams, OptimProblem, predictions, measures, elementPath);
     
gapProposal = 0;

 %% Out of the loop WindTurbines
    fnWT = fieldnames(MiCentral.Generators.WTNodes); % Field names for every WindTurbines
    %numWT = length(fnWT); % number of WTnodes
%% Out of the loop PhotoVoltaic
    fnPV = fieldnames(MiCentral.Generators.PVNodes); % Field names for every PhotoVoltaic
    %numPV = length(fnPV); % number of PVnodes
%% Out of the loop Diesels
    fnDiesel = fieldnames(MiCentral.StabilityControllers.DieselNodes); % Field names for every Diesel
    %numDiesel = length(fnDiesel); % number of Diesels
%% Out of the loop Hydrolics
    fnHydro = fieldnames(MiCentral.StabilityControllers.HydroNodes); % Field names for every Diesel
    %numHydro = length(fnHydro); % number of Diesels
 %% Out of the loop Consumers
    fnC = fieldnames(MiCentral.Consumers.ConsumerNodes); % fnC = field name consumers
    numCon = length(fnC);
    gPowerGapConsumers = 0;
     
infoGrid = struct('fnWT',{fnWT},'fnPV',{fnPV}, 'fnDiesel',{fnDiesel}, 'fnHydro',{fnHydro});

%% This loop is gonna be useful for creating different 
for timeSlot = 1 : 24
    tic % Start stopwatch
    % For each timeSlot start with a low price and raise if necessary
    initPrice = 0.01; 
    
    % Read the consumer's demand
    for i=1:numCon
        itself = MiCentral.Consumers.ConsumerNodes.(fnC{i});
        gPowerGapConsumers = gPowerGapConsumers + itself.getPowerWanted( );
    end
    gPowerGapConsumers 

    solutionData = solveOptimProblem( initPrice, timeSlot, MiCentral,... 
        percentOverPower, gPowerGapConsumers, infoGrid);
    time = toc
    % pause( ((tSample)*60*60) - time ); % Wait until the next timeSlot
    pause ( 2 - time );
end
