function [ outData ] = solveOptimProblem( pPrice, pTimeSlot, pMiCentral, pPercentOverPower, pPowerGapConsumers, pInfoGrid )
    %FUNCMAINPROGRAM Summary of this function goes here
    %   Detailed explanation goes here
    
    pTimeSlot = pTimeSlot + 1;
    gPrice = raisePrice( pPrice ) % Euros per KWh
    haveToStop = pMiCentral.OptimProblem.possibleSolution;
    
    % Struct to store the solutions for the grid
    f1 = 'optimPrice';
    v1 = {0};
    % outData = struct(f1,v1,'optimPower',{},'fuelConsumption',{}, 'waterConsumption',{}); 
    outData = zeros(1,4);
    solMatrix =  zeros(1000, 4);
    gapProposal = 0;
    
    fnWT = pInfoGrid(1).fnWT;
    fnPV = pInfoGrid(1).fnPV;
    fnDiesel = pInfoGrid(1).fnDiesel;
    fnHydro = pInfoGrid(1).fnHydro;
    
    numWT = length(fnWT); % number of WTnodes
    numPV = length(fnPV); % number of PVnodes
    numDiesel = length(fnDiesel); % number of Diesels
    numHydro = length(fnHydro); % number of Diesels
     
    %% Control variables
    tooMuchPower = false;
    %% Loop
     while ~haveToStop
        %% WindTurbines
        freqWT = 0;
            totalPowWT = 0;
            powWT = 0;
            sumFreqWT = 0;
            totalFreqWT = 0;
            
            cd ../Models;
            % Loop for getting total frequency and power for all the WTNodes
            for cWT = 1:numWT
                freqWT = pMiCentral.Generators.WTNodes.( fnWT{cWT} ).getFreqFromEuro( gPrice ); % Freq of the WTNode number 'c'
                sumFreqWT = sumFreqWT + freqWT; % Sum of all frequencies
                powWT = pMiCentral.Generators.WTNodes.( fnWT{cWT} ).getPowerFromFreq( freqWT ); 
                totalPowWT = totalPowWT + powWT   % Sum the power of the WTNode 'c' and sum it to the total
            end    

            totalFreqWT = sumFreqWT / numWT % Result freq of WT Grid sent to Central eNode
            totalPowWT          % Result total power of WT Grid sent to Central eNode

        %     gPrice = 0.0648; % It's the starting price of the PV for now. Needs to change
        %% PhotoVoltaics
            freqPV = 0;
            totalPowPV = 0;
            powPV=0;
            sumFreqPV = 0;
            totalFreqPV = 0;

            % Loop for getting total frequency and power for all the PVNodes
            for cPV = 1:numPV
                freqPV = pMiCentral.Generators.PVNodes.( fnPV{cPV} ).getFreqFromEuro( gPrice ); % Freq of the PVNode number 'c'
                sumFreqPV = sumFreqPV + freqPV; % Sum of all frequencies
               powPV = powPV + pMiCentral.Generators.PVNodes.( fnPV{cPV} ).getPowerFromFreq( freqPV ) ; % Sum the power of the PVNode 'c' and sum it to the total
            end

            % Results of the PV Grid sent to the Central eNode
            totalFreqPV = sumFreqPV / numPV
            totalPowPV = powPV
            generatorsTotalFreq = str2num( sprintf('%.2f', (sumFreqPV + sumFreqWT) / (numPV + numWT) ))    % TOTAL FREQ WITHOUT Stab. Controllers
            generatorsTotalPow = totalPowWT + totalPowPV                                                   % TOTAL POWER WITHOUT Stab. Controllers

        %% Mange the Price for all the generators
            %generatorsTotalEuro = generatorsTotalPow * pMiCentral.OptimParams.tSample * (gPrice/(1000*pMiCentral.OptimParams.tSample))
            % generators is in Watts but we want a price in euro per
            % kilowatt for each 15 min
%             generatorsTotalEuro = generatorsTotalPow *(gPrice/(1000*pMiCentral.OptimParams.tSample))
            generatorsTotalEuro = gPrice * (numWT+numPV);

        %% Caculate the power needed for stability
            powForStability = pMiCentral.getPowerForStability( generatorsTotalFreq, pPowerGapConsumers)

        %% Fix the stabilization problem
        gridFreq = generatorsTotalFreq; % The grid frequency is generators frequency because otherwise you have no stablility control

        SSIP = true; % Means "Stable Solution Is Possible"
        totalPowHydro = 0;
        totalPowD = 0;
        totalPowStab = totalPowHydro + totalPowD;
        
        while( powForStability > totalPowStab && SSIP )
            %% Hydros
                powHydro = 0;
                totalConsumptionH = 0;
                euroHydro = 0;
                totalEuroHydro = 0;
                cHydro = 1;

                % Loop for getting total frequency and power for all the Hydros
                while ( cHydro <= numHydro ) && ( powForStability > totalPowStab )

                    waterLvl = pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro} ).getWaterLevel( );
                    waterMax = pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro} ).getWaterMax( );

                    if( waterLvl > waterMax * 0.1 ) % Never go under the 10% of water level
                        powHydro = pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro} ).setRealPower( powForStability );

                        consHydro = pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro} ).calcWaterConsumption( powHydro );
                       % powForStability = powForStability - powHydro;
                        euroHydro = pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro} ).calcWaterEuro( consHydro );
                        
                       % Add to the totals
                        totalPowHydro = totalPowHydro + powHydro;
                        totalConsumptionH = totalConsumptionH + consHydro;
                        totalEuroHydro = totalEuroHydro + euroHydro;
                    else
                        powHydro = 0;
                        consHydro = 0;
                        euroHydro = 0;
                    end
                    cHydro = cHydro + 1; % Increment the counter
                end
                % Print the totals from Hydros
                totalPowHydro 
                totalConsumptionH 
                totalEuroHydro 
                % totalEuroHydroKWh = (totalEuroHydro * totalConsumptionH) / totalPowHydro;
                
                % Reasign totalPowStab value after Hydros
                totalPowStab = totalPowHydro + totalPowD;

                
%                 if powForStability > totalPowStab % Stability problem already SOLVED
%                     stableSolution = false;
%                 else 

            %% Diesels
                powDiesel = 0;
                totalConsumptionD = 0; 
                euroDiesel = 0;
                totalEuroDiesel = 0;
                cDiesel = 1;

                % Loop for getting total frequency and power for all the DieselNodes
                while ( cDiesel <= numDiesel ) && ( powForStability > totalPowStab )

                    powDiesel = pMiCentral.StabilityControllers.DieselNodes.( fnDiesel{cDiesel} ).setRealPower( powForStability );
                    %powForStability = powForStability - powDiesel;
                    consDiesel = pMiCentral.StabilityControllers.DieselNodes.(  fnDiesel{cDiesel} ).calcFuelConsumption( powDiesel );
                    euroDiesel = pMiCentral.StabilityControllers.DieselNodes.(  fnDiesel{cDiesel} ).calcFuelEuro(consDiesel, pMiCentral.OptimParams.euroFuel);
                    
                    % Add to the Diesel totals
                    totalPowD = totalPowD + powDiesel;
                    totalConsumptionD = totalConsumptionD + consDiesel;
                    totalEuroDiesel = totalEuroDiesel + euroDiesel;
                    
                    cDiesel = cDiesel + 1; % Increment the counter
                end
                
            % Print the total values of the 
            totalPowD               % Total power in Watts produced by all the Diesels for this time slot
            totalConsumptionD    % Fuel consumption in litres per "tSample" of your parameters
            totalEuroDiesel         % Total price in Euros per each time slot 
            % totalEuroDieselKWh = (totalEuroDiesel * totalConsumptionD) / totalPowD;
            
            fprintf('N� of Hydros = %d ; N� of Diesels = %d \n', cHydro-1, cDiesel-1);
            
            % Reasign totalPowStab value after Diesels
            totalPowStab = totalPowD + totalPowHydro;
            
            if ( powForStability > totalPowStab )
                SSIP = false;
                fprintf('There is no stable solution for this Proposal. Add more Stability Controllers to the grid.\n');
            end
        end
        % ^ OKAY ^
        
        
            %% Compare previous Gap
            
            prevGapProposal = gapProposal;
            newGapProposal = totalPowStab + generatorsTotalPow;
            
            % We have to have only 1 diesel in our GRID! 
            gPrice
            if gPrice >= (  6 )
                fprintf('Is impossible to fix the GAP, add more producers\n');
                haveToStop = true;
                
            else
                %% Compare Gaps 
                %REMEMBER TO CHANGE GPOSSIBLESOLUTION HERE, ALREADY USED
                billConsumers = generatorsTotalEuro + totalEuroDiesel + totalEuroHydro
                
                if ~SSIP
                    fprintf('Add more Stability Controllers\n');
%                     haveToStop = true;
                else
                    % The power production can be 10% higher than the gap, not more
                    if newGapProposal + ( newGapProposal * pPercentOverPower ) >= pPowerGapConsumers  
                        % Store the solution
                        solIdx = find( solMatrix == 0, 1 );
                                                
                        solMatrix( solIdx, :) = [ billConsumers, generatorsTotalPow, totalPowStab, gPrice]; 
                        fprintf('Solution found! \n\n');
                        fprintf('The possible price in the %i th solution and is %f euros per time slot.\n', solIdx, billConsumers);
                    else
                        % it is ok if we produce 10 percent more because we
                        % can store this amount probably in the future in
                        % batteries
                        fprintf('we need to stop because we are going to produce more than we can consume (more than 10 percent)');
                        haveToStop = true;
                        tooMuchPower = true;
                        % pause
                    end
                end
            end
            % Raise the price
            cd ../MainProgram
            if gPrice <= 6
%                 if gPrice <= pMiCentral.OptimParams.euroFuel
                gPrice = raisePrice( gPrice );
                
            else
                haveToStop = true;
            end
            
            %% Clean the scum
%                 clear euroDiesel freqPV freqWT generatorsTotalFreq generatorsTotalPow...
%                     powDiesel powPV powWT prevPrice sumFreqPV sumFreqWT totalEuroD totalFreqPV totalFreqWT...
%                     totalPowD totalPowPV totalPowWT;
     end
        
    % Remember to pass the time slot via parameter
    if tooMuchPower 
        return
    else
    %% when OPTIMAL SOLUTION is FOUNDED
        cd ../Utils;
        [optimPrice, optimPower] = dispOptimalSolution( solMatrix );
        % Have to store the optimal, use it and do the proper things for the next time slot
                
    %% Consumption update of the Stabilizers
        cd ../Models;
        for cHydro2=1 : (cHydro-1)
           thisPowHydro =  pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro2} ).Model.realPower;
           
           thisConsHydro =  pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro2} ).calcWaterConsumption( thisPowHydro );
           pMiCentral.StabilityControllers.HydroNodes.(  fnHydro{cHydro2} ).setWaterLevel(-thisConsHydro); % Remember we are substracting water from water lvl
        end

        for cDiesel2=1 : (cDiesel-1)
            thisPowDiesel = pMiCentral.StabilityControllers.DieselNodes.( fnDiesel{cDiesel2} ).Model.realPower;
            thisConsDiesel = pMiCentral.StabilityControllers.DieselNodes.( fnDiesel{cDiesel2} ).calcFuelConsumption( thisPowDiesel );
            pMiCentral.StabilityControllers.DieselNodes.( fnDiesel{cDiesel2} ).setFuelLvl(-thisConsDiesel); % Remember we are substracting water from water lvl
        end
        
        outData(1,1) = optimPrice;
        outData(1,2) = optimPower;
%         outData.fuelConsumption = ;
%         outData.waterConsumption = ;

        figure

        subplot(2,2,1)
        plot( solMatrix(:,1), solMatrix(:,4) )
        title('gPriceX and euroBillY')

        subplot(2,2,2);
        plot(solMatrix(:,2));
        title('Pgen')

        subplot(2,2,3);
        plot(solMatrix(:,1));
        title('LoopX and euroBillY')

        subplot(2,2,4);
        plot(solMatrix(:,3));
    %     hold on;
    %     plot(pMiCentral.OptimParams.FreqPowerCurve(2,:));
         title('Pstab')
    %     hold off
    end
end
