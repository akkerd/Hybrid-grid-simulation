function [ outPrice ] = raisePrice( pPrice )
%RAISEPRICE Summary of this function goes here
%   Detailed explanation goes here
    priceStep = 0.03;
    outPrice = pPrice + priceStep;
end

