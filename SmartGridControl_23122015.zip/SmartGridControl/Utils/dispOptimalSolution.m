function [ outPrice, outPower ] = dispOptimalSolution( pMat )
%DISPOPTIMALSOLUTION Summary of this function goes here
%   Detailed explanation goes here
    %[value, index] = min(reshape( pMat, numel(pMat), 1) );
    %[i,j] = ind2sub(size(pMat), index);
%     [value, index] = min( find( pMat ( :, 1) > 0, ) ); % Find the minimum value bigger than zero, 
    [row, col, values] =  find( pMat ( :, 1) );
    [optimPrice, index] = min( values ); % Find the minimum value bigger than zero, 
    
    outPower = pMat(index, 2) + pMat(index, 3);
    outPrice = optimPrice;
    
    fprintf('\n The optimal solution is %f and it was finded at the %f th s', outPrice, index);
    
end

