function [ outPrice ] = priceTransform( pPrice )
%priceTransform Summary of this function goes here
%   This is for changing the price from kWh to Watts per 15 minutes
    
    outPrice = ( pPrice / 1000 ) * 0.25;
end

