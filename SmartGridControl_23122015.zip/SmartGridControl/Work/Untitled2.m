?xml version="1.0" encoding="utf-8"?>
<eNode>
	<eNodeType>CentraleNode</eNodeType>
	<Mode>autonomous</Mode>
	<GeneralInformation>
		<XMS_ID>CentraleNode</XMS_ID>
   </GeneralInformation>
   <Schedule>
   </Schedule>
   
   <Model>
        <TypeOfeNodes>
            <type1> 
                <name>Consumer</name>
                <path>.\Models\Consumers</path>
            </type1>
            <type2> 
                <name>Diesel</name>
                <path>.\Models\Diesel</path>
            </type2>
            <type3> 
                <name>WindTurbine</name>
                <path>.\Models\WindTurbine</path>
            </type3>
            <type4> 
                <name>Battery</name>
                <path>.\Models\Battery</path>
            </type4>
        </TypeOfeNodes>
   </Model>
   <OptimParams>
        <MaxIter>100</MaxIter>
        <FreqPowerCurve>[47.5 52.5; 20000 100]</FreqPowerCurve>
        <FactorCurve>[100 20000; 0.1 1]</FactorCurve>
        <euroFuel>1.2</euroFuel>
   </OptimParams>
</eNode>

